create_clock -name clk -period 20.000 [get_ports {clk}]
# Switches and button are asynchronous board inputs. Their first flops are CDC.
# Review Quartus CDC/timing reports; this preparation does not claim full timing closure.
