create_clock -name clk_50_mhz -period 20.000 [get_ports {clk}]
